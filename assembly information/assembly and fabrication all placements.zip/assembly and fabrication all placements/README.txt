Place all components listed in "bill of materials all placed components" at positions listed in "component positions".

list of components includes all components in the schematic and pcb design, including not placed components. 

Place components marked REQUIRED OR OPTIONAL. Do not place components marked NOT PLACED

List of distributors and part numbers for LXML-PD03 (luxeon deep red 655nm) is included separately

